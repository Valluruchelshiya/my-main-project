<?php

$conn = mysqli_connect("localhost","root","","register");

if(!$conn){
  die("connection error");
}

?>
