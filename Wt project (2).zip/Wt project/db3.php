<?php

$conn = mysqli_connect("localhost","root","","notification");

if(!$conn){
  die("connection error");
}

?>
