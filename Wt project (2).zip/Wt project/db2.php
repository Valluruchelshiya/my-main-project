<?php

$conn = mysqli_connect("localhost","root","","result");

if(!$conn){
  die("connection error");
}

?>