<?php

$conn = mysqli_connect("localhost","root","","timetable");

if(!$conn){
  die("connection error");
}

?>