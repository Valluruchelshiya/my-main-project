<?php

$conn = mysqli_connect("localhost","root","","chat");

if(!$conn){
  die("connection error");
}

?>