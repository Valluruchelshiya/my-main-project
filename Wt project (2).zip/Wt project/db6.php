<?php

$conn = mysqli_connect("localhost","root","","achat");

if(!$conn){
  die("connection error");
}

?>